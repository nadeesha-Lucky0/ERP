-- =========================================================================
-- FIFOERP - Enterprise FIFO Inventory & Operations Management
-- Database Schema for: fifonew
-- Target Server: MySQL 8.0+ / MariaDB 10.4+ (XAMPP Default)
-- =========================================================================

CREATE DATABASE IF NOT EXISTS `fifonew` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `fifonew`;

SET FOREIGN_KEY_CHECKS = 0;

-- -------------------------------------------------------------------------
-- 1. Roles
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `roles` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL UNIQUE,
    `display_name` VARCHAR(100) NOT NULL,
    `description` TEXT,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 2. Power Stations / Locations
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `locations` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(120) NOT NULL UNIQUE,
    `code` VARCHAR(30) NOT NULL UNIQUE,
    `type` VARCHAR(50) DEFAULT 'Hydroelectric',
    `capacity_mw` VARCHAR(50) DEFAULT NULL,
    `province` VARCHAR(100) DEFAULT NULL,
    `district` VARCHAR(100) DEFAULT NULL,
    `description` TEXT DEFAULT NULL,
    `status` VARCHAR(20) DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 3. Departments
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `departments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `location_id` INT DEFAULT 1,
    `name` VARCHAR(100) NOT NULL UNIQUE,
    `code` VARCHAR(30) NOT NULL UNIQUE,
    `description` TEXT DEFAULT NULL,
    `head_of_department` VARCHAR(100) DEFAULT NULL,
    `status` VARCHAR(20) DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_dept_location` FOREIGN KEY (`location_id`) REFERENCES `locations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 4. Users
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `role_id` INT NOT NULL,
    `location_id` INT DEFAULT 1,
    `username` VARCHAR(60) NOT NULL UNIQUE,
    `email` VARCHAR(120) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(120) NOT NULL,
    `department` VARCHAR(100) DEFAULT 'Central Stores',
    `phone` VARCHAR(30) DEFAULT NULL,
    `avatar_color` VARCHAR(10) DEFAULT '#0d9488',
    `status` VARCHAR(20) DEFAULT 'active',
    `last_login_at` DATETIME DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_user_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 5. Role Permissions Matrix
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `role_permissions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `role_id` INT NOT NULL,
    `permission_key` VARCHAR(100) NOT NULL,
    `is_granted` TINYINT DEFAULT 1,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_role_perm` (`role_id`, `permission_key`),
    CONSTRAINT `fk_perm_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 6. FIFO Batches (Core Inventory)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `fifo_batches` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `location_id` INT DEFAULT 1,
    `batch_number` VARCHAR(50) NOT NULL UNIQUE,
    `sku` VARCHAR(50) NOT NULL,
    `item_name` VARCHAR(150) NOT NULL,
    `category` VARCHAR(100) DEFAULT 'Standard',
    `initial_quantity` INT NOT NULL,
    `remaining_quantity` INT NOT NULL,
    `unit_cost` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `received_date` DATE NOT NULL,
    `expiry_date` DATE DEFAULT NULL,
    `location_bin` VARCHAR(50) DEFAULT 'Zone A-01',
    `status` VARCHAR(20) DEFAULT 'active', -- active, frozen, exhausted
    `freeze_status` VARCHAR(20) DEFAULT 'unfrozen', -- unfrozen, frozen
    `freeze_session_id` INT NULL,
    `created_by` INT DEFAULT 1,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_sku_status` (`sku`, `status`),
    INDEX `idx_received_date` (`received_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 7. Inventory Transactions (Stock Ledger)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `inventory_transactions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `location_id` INT DEFAULT 1,
    `batch_id` INT NULL,
    `transaction_type` VARCHAR(30) NOT NULL, -- GRN_RECEIPT, MATERIAL_ISSUE, STOCK_TRANSFER, COST_ADJUSTMENT, RECONCILIATION
    `document_no` VARCHAR(60) NOT NULL,
    `sku` VARCHAR(50) NOT NULL,
    `item_name` VARCHAR(150) NOT NULL,
    `quantity` INT NOT NULL,
    `unit_price` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `total_value` DECIMAL(14, 2) NOT NULL DEFAULT 0.00,
    `transaction_date` DATE NOT NULL,
    `reference_no` VARCHAR(60) NULL,
    `destination_code` VARCHAR(50) NULL,
    `department_name` VARCHAR(100) NULL,
    `created_by` INT NULL,
    `status` VARCHAR(20) DEFAULT 'POSTED',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_doc_no` (`document_no`),
    INDEX `idx_tx_date` (`transaction_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 8. Unposted / Workflow Documents (GRN & Issues)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `unposted_documents` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `location_id` INT DEFAULT 1,
    `doc_type` VARCHAR(30) NOT NULL, -- GRN, ISSUE
    `doc_no` VARCHAR(60) NOT NULL UNIQUE,
    `doc_date` DATE NOT NULL,
    `receipt_from` VARCHAR(150) NULL, -- Supplier for GRN
    `department_code` VARCHAR(50) NULL,
    `destination_code` VARCHAR(50) NULL,
    `warehouse` VARCHAR(100) DEFAULT 'Main Store Bay-01',
    `status` VARCHAR(30) DEFAULT 'Draft', -- Draft, Validated, Approved, Posted, Cancelled
    `invoice_total` DECIMAL(14, 2) DEFAULT 0.00,
    `vat` DECIMAL(10, 2) DEFAULT 0.00,
    `transport` DECIMAL(10, 2) DEFAULT 0.00,
    `nbt` DECIMAL(10, 2) DEFAULT 0.00,
    `other_cost` DECIMAL(10, 2) DEFAULT 0.00,
    `invoice_number` VARCHAR(60) NULL,
    `order_reference` VARCHAR(60) NULL,
    `remarks` TEXT NULL,
    `created_by` INT DEFAULT 1,
    `validated_by` INT NULL,
    `approved_by` INT NULL,
    `posted_by` INT NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `unposted_document_items` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `document_id` INT NOT NULL,
    `batch_id` INT NULL,
    `sku` VARCHAR(50) NOT NULL,
    `item_name` VARCHAR(150) NOT NULL,
    `requested_quantity` INT NOT NULL DEFAULT 0,
    `quantity` INT NOT NULL,
    `unit_cost` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `total_cost` DECIMAL(14, 2) NOT NULL DEFAULT 0.00,
    `bin_location` VARCHAR(50) DEFAULT 'Bay A',
    `expiry_date` DATE NULL,
    CONSTRAINT `fk_unposted_items_doc` FOREIGN KEY (`document_id`) REFERENCES `unposted_documents` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 9. Physical Verification Sessions (PHV / Stock Count)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `phv_sessions` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `location_id` INT DEFAULT 1,
    `session_code` VARCHAR(50) NOT NULL UNIQUE,
    `session_title` VARCHAR(150) NOT NULL,
    `verification_date` DATE NOT NULL,
    `freeze_status` VARCHAR(20) DEFAULT 'unfrozen', -- unfrozen, frozen
    `frozen_at` DATETIME NULL,
    `frozen_by` INT NULL,
    `unfrozen_at` DATETIME NULL,
    `unfrozen_by` INT NULL,
    `status` VARCHAR(30) DEFAULT 'Draft', -- Draft, Frozen, In_Counting, Validated, Approved, Posted, Closed
    `remarks` TEXT NULL,
    `created_by` INT DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `phv_entries` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `session_id` INT NOT NULL,
    `batch_id` INT NOT NULL,
    `sku` VARCHAR(50) NOT NULL,
    `item_name` VARCHAR(150) NOT NULL,
    `bin_location` VARCHAR(50) NULL,
    `book_quantity` INT NOT NULL DEFAULT 0,
    `physical_quantity` INT NOT NULL DEFAULT 0,
    `variance_quantity` INT GENERATED ALWAYS AS (physical_quantity - book_quantity) STORED,
    `unit_cost` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `variance_value` DECIMAL(14, 2) GENERATED ALWAYS AS ((physical_quantity - book_quantity) * unit_cost) STORED,
    `verified_by` INT NULL,
    `remarks` VARCHAR(255) NULL,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_phv_session` FOREIGN KEY (`session_id`) REFERENCES `phv_sessions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 10. Cash Book Entries
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cash_book_entries` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `location_id` INT DEFAULT 1,
    `entry_date` DATE NOT NULL,
    `voucher_no` VARCHAR(50) NOT NULL UNIQUE,
    `entry_type` VARCHAR(20) NOT NULL, -- Receipt, Payment
    `account_title` VARCHAR(150) NOT NULL,
    `amount` DECIMAL(12, 2) NOT NULL,
    `payee_or_source` VARCHAR(150) NULL,
    `description` TEXT NULL,
    `status` VARCHAR(30) DEFAULT 'Verified',
    `created_by` INT DEFAULT 1,
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 11. Payslip Cancellations
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `payslip_cancellations` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `location_id` INT DEFAULT 1,
    `cancellation_ref` VARCHAR(50) NOT NULL UNIQUE,
    `payslip_no` VARCHAR(50) NOT NULL,
    `employee_name` VARCHAR(150) NOT NULL,
    `epf_no` VARCHAR(50) DEFAULT NULL,
    `department` VARCHAR(100) DEFAULT 'Hydro Operations',
    `pay_period` VARCHAR(30) NOT NULL,
    `amount` DECIMAL(12, 2) NOT NULL DEFAULT 0.00,
    `reason` TEXT NOT NULL,
    `requested_by` INT DEFAULT 1,
    `approved_by` INT NULL,
    `status` VARCHAR(30) DEFAULT 'Pending Review', -- Pending Review, Approved, Rejected
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 12. CPC Fuel Procurements (Ceylon Petroleum Corporation)
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cpc_procurements` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `location_id` INT DEFAULT 1,
    `order_no` VARCHAR(50) NOT NULL UNIQUE,
    `fuel_type` VARCHAR(100) NOT NULL DEFAULT 'Super Diesel / Auto Diesel',
    `tank_id` VARCHAR(50) NOT NULL,
    `quantity_litres` DECIMAL(12, 2) NOT NULL,
    `unit_price_lkr` DECIMAL(10, 2) NOT NULL,
    `total_amount_lkr` DECIMAL(14, 2) NOT NULL,
    `consignment_date` DATE NOT NULL,
    `delivery_ref` VARCHAR(60) NOT NULL,
    `bowser_no` VARCHAR(50) DEFAULT NULL,
    `supplier_depot` VARCHAR(100) DEFAULT 'Kolonnawa / Muthurajawela Depot',
    `status` VARCHAR(30) DEFAULT 'Received & Pumped',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 13. Diesel Price Logs
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `diesel_price_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `effective_month` VARCHAR(20) NOT NULL,
    `fuel_type` VARCHAR(100) NOT NULL DEFAULT 'Auto Diesel',
    `avg_price_per_litre` DECIMAL(10, 2) NOT NULL,
    `total_procured_litres` DECIMAL(14, 2) NOT NULL,
    `total_procurement_cost` DECIMAL(14, 2) NOT NULL,
    `price_trend` VARCHAR(20) DEFAULT 'Stable', -- Increased, Decreased, Stable
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 14. Cost Adjustments
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cost_adjustments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `adjustment_ref` VARCHAR(50) NOT NULL UNIQUE,
    `batch_id` INT NULL,
    `sku` VARCHAR(50) NOT NULL,
    `item_name` VARCHAR(150) NOT NULL,
    `old_unit_cost` DECIMAL(12, 2) NOT NULL,
    `new_unit_cost` DECIMAL(12, 2) NOT NULL,
    `variance_per_unit` DECIMAL(12, 2) NOT NULL,
    `remaining_qty` INT NOT NULL,
    `total_valuation_delta` DECIMAL(14, 2) NOT NULL,
    `reason` TEXT NOT NULL,
    `authorized_by` INT NULL,
    `status` VARCHAR(30) DEFAULT 'Approved & Applied',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 15. Quantity Corrections
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `qty_corrections` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `correction_ref` VARCHAR(50) NOT NULL UNIQUE,
    `batch_id` INT NULL,
    `sku` VARCHAR(50) NOT NULL,
    `item_name` VARCHAR(150) NOT NULL,
    `allocated_qty_before` INT NOT NULL,
    `corrected_allocated_qty` INT NOT NULL,
    `qty_released_to_free_stock` INT NOT NULL,
    `work_order_ref` VARCHAR(60) DEFAULT NULL,
    `reason` TEXT NOT NULL,
    `authorized_by` INT NULL,
    `status` VARCHAR(30) DEFAULT 'Corrected & Unlocked',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 16. Issue Categories & Destination Codes
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `issue_destination_codes` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `category_code` VARCHAR(30) NOT NULL,
    `category_name` VARCHAR(100) NOT NULL,
    `destination_code` VARCHAR(50) NOT NULL UNIQUE,
    `destination_name` VARCHAR(150) NOT NULL,
    `description` TEXT NULL,
    `status` VARCHAR(20) DEFAULT 'active',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 17. Stock Transfers
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `stock_transfers` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `transfer_ref` VARCHAR(50) NOT NULL UNIQUE,
    `from_location` VARCHAR(100) NOT NULL DEFAULT 'Victoria Central Bay',
    `to_department` VARCHAR(100) NOT NULL,
    `sku` VARCHAR(50) NOT NULL,
    `item_name` VARCHAR(150) NOT NULL,
    `quantity` INT NOT NULL,
    `transfer_date` DATE NOT NULL,
    `status` VARCHAR(30) DEFAULT 'Completed',
    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- -------------------------------------------------------------------------
-- 18. Activity Logs
-- -------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `activity_logs` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT NULL,
    `action` VARCHAR(100) NOT NULL,
    `entity_type` VARCHAR(50) DEFAULT NULL,
    `entity_id` INT DEFAULT NULL,
    `details` TEXT DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- =========================================================================
-- SEED DATA INSERTION
-- =========================================================================

-- Roles
INSERT INTO `roles` (`id`, `name`, `display_name`, `description`) VALUES
(1, 'super_admin', 'Super Administrator', 'Full system access and master configuration rights'),
(2, 'admin', 'Station Administrator', 'Power station operational management and approvals'),
(3, 'auditor', 'Store Auditor', 'Physical verification, AV 7 reports and inspection privileges'),
(4, 'store_keeper', 'Store Keeper', 'Material receipts, GRN entry, issues and stock transfers'),
(5, 'operator', 'Station Operator', 'Job-wise requests and view inquiry permissions')
ON DUPLICATE KEY UPDATE `display_name`=VALUES(`display_name`);

-- Locations
INSERT INTO `locations` (`id`, `name`, `code`, `type`, `capacity_mw`, `province`, `district`, `description`) VALUES
(1, 'Victoria Power Station', 'VIC-PS-01', 'Hydroelectric', '210 MW', 'Central', 'Kandy', 'Largest hydroelectric facility on the Mahaweli river'),
(2, 'Kotmale Power Station', 'KOT-PS-02', 'Hydroelectric', '201 MW', 'Central', 'Nuwara Eliya', 'Underground power station on Kotmale Oya'),
(3, 'Randenigala Power Station', 'RAN-PS-03', 'Hydroelectric', '126 MW', 'Central', 'Kandy', 'Multi-purpose dam and reservoir complex'),
(4, 'Samanalawewa Power Station', 'SAM-PS-04', 'Hydroelectric', '124 MW', 'Sabaragamuwa', 'Ratnapura', 'Hydro power station on Walawe river')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- Departments
INSERT INTO `departments` (`id`, `location_id`, `name`, `code`, `description`, `head_of_department`) VALUES
(1, 1, 'Electrical Generation & Control', 'ELEC-GEN', 'Turbine alternators and 220kV switchgear', 'Eng. K. Perera'),
(2, 1, 'Mechanical Maintenance', 'MECH-MAINT', 'Hydraulic governors and penstock valves', 'Eng. S. Wickramasinghe'),
(3, 1, 'Civil & Dam Safety', 'CIVIL-DAM', 'Dam instrumentation, seepage monitoring & spillway', 'Eng. N. Fernando'),
(4, 1, 'Central Stores & Logistics', 'STORES-01', 'Spares warehouse and consumable inventory', 'Mr. M. Jayasinghe'),
(5, 1, 'Operations & Shift Control', 'OPS-CTRL', '24/7 Grid dispatch and generation shift operations', 'Eng. R. Dissanayake')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- Users (Default password: admin123)
INSERT INTO `users` (`id`, `role_id`, `location_id`, `username`, `email`, `password_hash`, `full_name`, `department`, `phone`, `avatar_color`, `status`) VALUES
(1, 1, 1, 'admin', 'admin@egl.lk', '$2y$10$totTQ4J344v81XcuDsKiJ.gnICG4xUHXOCOeFGENLUFq8zkVj4KEm', 'EGL Administrator', 'Central Stores & Logistics', '+94 81 235 6789', '#0d9488', 'active'),
(2, 4, 1, 'storekeeper', 'stores@egl.lk', '$2y$10$totTQ4J344v81XcuDsKiJ.gnICG4xUHXOCOeFGENLUFq8zkVj4KEm', 'Mahinda Jayasinghe', 'Central Stores & Logistics', '+94 81 235 6790', '#2563eb', 'active'),
(3, 3, 1, 'auditor', 'auditor@egl.lk', '$2y$10$totTQ4J344v81XcuDsKiJ.gnICG4xUHXOCOeFGENLUFq8zkVj4KEm', 'Sunil Wickrama', 'Audit & Inspection', '+94 81 235 6791', '#7c3aed', 'active')
ON DUPLICATE KEY UPDATE `full_name`=VALUES(`full_name`);

-- FIFO Batches (Realistic EGL Hydro Plant Spares & Materials)
INSERT INTO `fifo_batches` (`id`, `location_id`, `batch_number`, `sku`, `item_name`, `category`, `initial_quantity`, `remaining_quantity`, `unit_cost`, `received_date`, `expiry_date`, `location_bin`, `status`, `freeze_status`) VALUES
(1, 1, 'BATCH-2026-001', 'LUB-VG46-200L', 'Turbine Lubricating Oil Shell Turbo T 46', 'Lubricants & Oils', 50, 28, 92500.00, '2026-01-10', '2028-01-10', 'Bay-Oil-A1', 'active', 'unfrozen'),
(2, 1, 'BATCH-2026-002', 'LUB-VG46-200L', 'Turbine Lubricating Oil Shell Turbo T 46', 'Lubricants & Oils', 40, 40, 96000.00, '2026-02-15', '2028-02-15', 'Bay-Oil-A2', 'active', 'unfrozen'),
(3, 1, 'BATCH-2026-003', 'HYD-HOSE-2IN', 'High Pressure Hydraulic Hose 2" 350 Bar', 'Hydraulics', 30, 14, 48500.00, '2026-01-18', '2029-01-18', 'Rack-H-04', 'active', 'unfrozen'),
(4, 1, 'BATCH-2026-004', 'GRS-SHL-18KG', 'Generator Bearing Grease Shell Gadus S2', 'Lubricants & Oils', 60, 42, 38200.00, '2026-01-22', '2028-01-22', 'Bay-Oil-B1', 'active', 'unfrozen'),
(5, 1, 'BATCH-2026-005', 'FAN-TR-415V', 'Transformer Radiator Cooling Fan Motor 415V', 'Electrical Spares', 12, 6, 185000.00, '2026-02-01', NULL, 'Rack-E-12', 'active', 'unfrozen'),
(6, 1, 'BATCH-2026-006', 'BRU-ALT-SET', 'Carbon Brushes Set for Hydro Alternator', 'Electrical Spares', 80, 55, 14200.00, '2026-02-05', NULL, 'Bin-EB-03', 'active', 'unfrozen'),
(7, 1, 'BATCH-2026-007', 'VAL-PRV-100B', 'Pressure Relief Valve 100 Bar Penstock', 'Mechanical Spares', 8, 3, 245000.00, '2026-02-10', NULL, 'Rack-M-02', 'active', 'unfrozen'),
(8, 1, 'BATCH-2026-008', 'REL-DIG-MF', 'Digital Multi-Function Protection Relay ABB', 'Protection Systems', 6, 4, 460000.00, '2026-02-18', NULL, 'Vault-P-01', 'active', 'unfrozen'),
(9, 1, 'BATCH-2026-009', 'PMP-SUB-3PH', 'Submersible Drainage Sump Pump 3-Phase 15kW', 'Mechanical Spares', 10, 5, 310000.00, '2026-02-25', NULL, 'Rack-M-08', 'active', 'unfrozen'),
(10, 1, 'BATCH-2026-010', 'GSK-FLG-300', 'Spiral Wound Flange Gaskets 300mm PN40', 'Piping & Seals', 150, 110, 8400.00, '2026-03-01', NULL, 'Bin-GS-14', 'active', 'unfrozen')
ON DUPLICATE KEY UPDATE `item_name`=VALUES(`item_name`);

-- Unposted Documents (GRN & Issues in workflow)
INSERT INTO `unposted_documents` (`id`, `location_id`, `doc_type`, `doc_no`, `doc_date`, `receipt_from`, `department_code`, `destination_code`, `warehouse`, `status`, `invoice_total`, `vat`, `transport`, `remarks`) VALUES
(1, 1, 'GRN', 'GRN-2026-0089', '2026-03-02', 'Lanka Industrial Lubricants Ltd', 'STORES-01', 'DEST-ST-01', 'Main Store Bay-01', 'Validated', 2450000.00, 392000.00, 45000.00, 'Emergency lubricant procurement for Unit 02 overhaul'),
(2, 1, 'GRN', 'GRN-2026-0090', '2026-03-04', 'Kelani Cables PLC', 'STORES-01', 'DEST-ST-01', 'Main Store Bay-01', 'Draft', 820000.00, 131200.00, 15000.00, 'Control cabling consignment awaiting inspection'),
(3, 1, 'ISSUE', 'ISS-2026-0142', '2026-03-03', NULL, 'ELEC-GEN', 'DEST-GEN-U1', 'Main Store Bay-01', 'Approved', 285000.00, 0.00, 0.00, 'Bearing grease & filter replacement for Unit 01 turbine'),
(4, 1, 'ISSUE', 'ISS-2026-0143', '2026-03-04', NULL, 'MECH-MAINT', 'DEST-PEN-02', 'Main Store Bay-01', 'Draft', 97000.00, 0.00, 0.00, 'High pressure hydraulic hoses for governor oil pressure unit')
ON DUPLICATE KEY UPDATE `doc_no`=VALUES(`doc_no`);

-- Unposted Document Items
INSERT INTO `unposted_document_items` (`id`, `document_id`, `batch_id`, `sku`, `item_name`, `requested_quantity`, `quantity`, `unit_cost`, `total_cost`, `bin_location`) VALUES
(1, 1, 1, 'LUB-VG46-200L', 'Turbine Lubricating Oil Shell Turbo T 46', 25, 25, 98000.00, 2450000.00, 'Bay-Oil-A1'),
(2, 2, 6, 'BRU-ALT-SET', 'Carbon Brushes Set for Hydro Alternator', 50, 50, 16400.00, 820000.00, 'Bin-EB-03'),
(3, 3, 4, 'GRS-SHL-18KG', 'Generator Bearing Grease Shell Gadus S2', 5, 5, 38200.00, 191000.00, 'Bay-Oil-B1'),
(4, 3, 1, 'LUB-VG46-200L', 'Turbine Lubricating Oil Shell Turbo T 46', 1, 1, 94000.00, 94000.00, 'Bay-Oil-A1'),
(5, 4, 3, 'HYD-HOSE-2IN', 'High Pressure Hydraulic Hose 2" 350 Bar', 2, 2, 48500.00, 97000.00, 'Rack-H-04')
ON DUPLICATE KEY UPDATE `sku`=VALUES(`sku`);

-- Inventory Transactions (Stock Ledger History)
INSERT INTO `inventory_transactions` (`id`, `location_id`, `batch_id`, `transaction_type`, `document_no`, `sku`, `item_name`, `quantity`, `unit_price`, `total_value`, `transaction_date`, `destination_code`, `department_name`, `status`) VALUES
(1, 1, 1, 'GRN_RECEIPT', 'GRN-2026-0001', 'LUB-VG46-200L', 'Turbine Lubricating Oil Shell Turbo T 46', 50, 92500.00, 4625000.00, '2026-01-10', 'DEST-ST-01', 'Central Stores', 'POSTED'),
(2, 1, 1, 'MATERIAL_ISSUE', 'ISS-2026-0012', 'LUB-VG46-200L', 'Turbine Lubricating Oil Shell Turbo T 46', 12, 92500.00, 1110000.00, '2026-01-20', 'DEST-GEN-U1', 'Electrical Generation', 'POSTED'),
(3, 1, 1, 'MATERIAL_ISSUE', 'ISS-2026-0035', 'LUB-VG46-200L', 'Turbine Lubricating Oil Shell Turbo T 46', 10, 92500.00, 925000.00, '2026-02-02', 'DEST-GEN-U2', 'Electrical Generation', 'POSTED'),
(4, 1, 2, 'GRN_RECEIPT', 'GRN-2026-0024', 'LUB-VG46-200L', 'Turbine Lubricating Oil Shell Turbo T 46', 40, 96000.00, 3840000.00, '2026-02-15', 'DEST-ST-01', 'Central Stores', 'POSTED'),
(5, 1, 3, 'GRN_RECEIPT', 'GRN-2026-0005', 'HYD-HOSE-2IN', 'High Pressure Hydraulic Hose 2" 350 Bar', 30, 48500.00, 1455000.00, '2026-01-18', 'DEST-ST-01', 'Central Stores', 'POSTED'),
(6, 1, 3, 'MATERIAL_ISSUE', 'ISS-2026-0044', 'HYD-HOSE-2IN', 'High Pressure Hydraulic Hose 2" 350 Bar', 16, 48500.00, 776000.00, '2026-02-12', 'DEST-PEN-01', 'Mechanical Maintenance', 'POSTED')
ON DUPLICATE KEY UPDATE `document_no`=VALUES(`document_no`);

-- Physical Verification Session (Active Demo Session for AV 7 & Freeze Testing)
INSERT INTO `phv_sessions` (`id`, `location_id`, `session_code`, `session_title`, `verification_date`, `freeze_status`, `status`, `remarks`) VALUES
(1, 1, 'PHV-2026-Q1', 'Q1 Annual Stores Physical Verification (AV 7 Verification)', '2026-03-01', 'frozen', 'Validated', 'Board of Survey annual verification under AV 7 store audit regulation')
ON DUPLICATE KEY UPDATE `session_code`=VALUES(`session_code`);

-- Physical Verification Entries (with actual variances for AV 7 report display)
INSERT INTO `phv_entries` (`id`, `session_id`, `batch_id`, `sku`, `item_name`, `bin_location`, `book_quantity`, `physical_quantity`, `unit_cost`, `remarks`) VALUES
(1, 1, 1, 'LUB-VG46-200L', 'Turbine Lubricating Oil Shell Turbo T 46', 'Bay-Oil-A1', 28, 28, 92500.00, 'Exact count verified in drums'),
(2, 1, 3, 'HYD-HOSE-2IN', 'High Pressure Hydraulic Hose 2" 350 Bar', 'Rack-H-04', 14, 13, 48500.00, '1 unit deficit due to damaged coupler cut'),
(3, 1, 4, 'GRS-SHL-18KG', 'Generator Bearing Grease Shell Gadus S2', 'Bay-Oil-B1', 42, 42, 38200.00, 'Seal intact, physical check verified'),
(4, 1, 5, 'FAN-TR-415V', 'Transformer Radiator Cooling Fan Motor 415V', 'Rack-E-12', 6, 6, 185000.00, 'Heavy spares section verified'),
(5, 1, 6, 'BRU-ALT-SET', 'Carbon Brushes Set for Hydro Alternator', 'Bin-EB-03', 55, 57, 14200.00, '2 units surplus found from prior consignment package'),
(6, 1, 7, 'VAL-PRV-100B', 'Pressure Relief Valve 100 Bar Penstock', 'Rack-M-02', 3, 3, 245000.00, 'Preserved in wooden crates')
ON DUPLICATE KEY UPDATE `sku`=VALUES(`sku`);

-- CPC Fuel Procurements
INSERT INTO `cpc_procurements` (`id`, `location_id`, `order_no`, `fuel_type`, `tank_id`, `quantity_litres`, `unit_price_lkr`, `total_amount_lkr`, `consignment_date`, `delivery_ref`, `bowser_no`, `supplier_depot`) VALUES
(1, 1, 'CPC-PO-2026-011', 'Auto Diesel 500ppm (Industrial)', 'TANK-01 (Underground)', 33000.00, 345.50, 11401500.00, '2026-01-15', 'CPC/DEL/78219', 'WP-LY-4421', 'Kolonnawa Installation Depot'),
(2, 1, 'CPC-PO-2026-018', 'Auto Diesel 500ppm (Industrial)', 'TANK-02 (Auxiliary Generator)', 16500.00, 348.00, 5742000.00, '2026-02-08', 'CPC/DEL/79044', 'WP-LY-8832', 'Peradeniya Bulk Depot'),
(3, 1, 'CPC-PO-2026-027', 'Super Diesel 10ppm (High Performance)', 'TANK-03 (Dam Spillway Backup)', 6600.00, 362.00, 2389200.00, '2026-02-26', 'CPC/DEL/80112', 'SP-NA-1109', 'Peradeniya Bulk Depot')
ON DUPLICATE KEY UPDATE `order_no`=VALUES(`order_no`);

-- Diesel Price Logs
INSERT INTO `diesel_price_logs` (`id`, `effective_month`, `fuel_type`, `avg_price_per_litre`, `total_procured_litres`, `total_procurement_cost`, `price_trend`) VALUES
(1, '2025-11', 'Auto Diesel', 338.00, 49500.00, 16731000.00, 'Stable'),
(2, '2025-12', 'Auto Diesel', 342.50, 66000.00, 22605000.00, 'Increased'),
(3, '2026-01', 'Auto Diesel', 345.50, 49500.00, 17102250.00, 'Increased'),
(4, '2026-02', 'Auto Diesel', 348.00, 39600.00, 13780800.00, 'Increased'),
(5, '2026-03', 'Auto Diesel', 348.00, 33000.00, 11484000.00, 'Stable')
ON DUPLICATE KEY UPDATE `effective_month`=VALUES(`effective_month`);

-- Cash Book Entries
INSERT INTO `cash_book_entries` (`id`, `location_id`, `entry_date`, `voucher_no`, `entry_type`, `account_title`, `amount`, `payee_or_source`, `description`, `status`) VALUES
(1, 1, '2026-02-25', 'CB-V-2026-0041', 'Payment', 'Stores Emergency Freight & Handling', 34500.00, 'City Express Transport', 'Urgent air delivery charges for governor pressure sensor', 'Verified'),
(2, 1, '2026-02-28', 'CB-V-2026-0042', 'Payment', 'Petty Cash Local Purchase', 12800.00, 'Kandy Hardware Mart', 'Flange bolts & chemical gasket sealants for emergency leak fix', 'Verified'),
(3, 1, '2026-03-01', 'CB-V-2026-0043', 'Receipt', 'Surplus Metal Scrap Disposal Proceeds', 185000.00, 'Lanka Metal Recyclers', 'Scrap copper winding offcut auction recovery', 'Verified')
ON DUPLICATE KEY UPDATE `voucher_no`=VALUES(`voucher_no`);

-- Payslip Cancellations
INSERT INTO `payslip_cancellations` (`id`, `location_id`, `cancellation_ref` , `payslip_no`, `employee_name`, `epf_no`, `department`, `pay_period`, `amount`, `reason`, `status`) VALUES
(1, 1, 'PSC-2026-001', 'PAY-2026-02-088', 'P. K. Gunawardena', 'EPF-8821', 'Mechanical Maintenance', 'February 2026', 142500.00, 'Unpaid special overseas training leave not adjusted in payroll run', 'Approved'),
(2, 1, 'PSC-2026-002', 'PAY-2026-02-104', 'D. M. Jayalath', 'EPF-7650', 'Civil & Dam Safety', 'February 2026', 118200.00, 'Duplicate overtime allowance calculated for weekend spillway gate duty', 'Pending Review')
ON DUPLICATE KEY UPDATE `cancellation_ref`=VALUES(`cancellation_ref`);

-- Issue Destination Codes
INSERT INTO `issue_destination_codes` (`id`, `category_code`, `category_name`, `destination_code`, `destination_name`, `description`) VALUES
(1, 'TURB', 'Hydro Turbine Systems', 'DEST-GEN-U1', 'Unit 01 Francis Turbine & Generator', 'Turbine runner, shaft seal & guide bearings'),
(2, 'TURB', 'Hydro Turbine Systems', 'DEST-GEN-U2', 'Unit 02 Francis Turbine & Generator', 'Turbine runner, shaft seal & guide bearings'),
(3, 'TURB', 'Hydro Turbine Systems', 'DEST-GEN-U3', 'Unit 03 Francis Turbine & Generator', 'Turbine runner, shaft seal & guide bearings'),
(4, 'PEN', 'Penstock & High Pressure Gates', 'DEST-PEN-01', 'Main Penstock Intake Valve 01', 'Penstock butterfly valve and bypass piping'),
(5, 'PEN', 'Penstock & High Pressure Gates', 'DEST-PEN-02', 'Main Penstock Intake Valve 02', 'Penstock butterfly valve and bypass piping'),
(6, 'SWG', 'High Voltage Switchgear', 'DEST-SWG-220KV', '220kV Outdoor Switchyard Bay', 'SF6 Circuit breakers and isolators'),
(7, 'DAM', 'Dam Crest & Spillway', 'DEST-DAM-SP01', 'Radial Spillway Gate No. 01 & Winch', 'Hydraulic lifting rams and emergency cables'),
(8, 'ST', 'Central Store Stockholding', 'DEST-ST-01', 'Central Spares Warehouse Bay 01', 'Default storage allocation')
ON DUPLICATE KEY UPDATE `destination_code`=VALUES(`destination_code`);

-- Cost Adjustments
INSERT INTO `cost_adjustments` (`id`, `adjustment_ref`, `batch_id`, `sku`, `item_name`, `old_unit_cost`, `new_unit_cost`, `variance_per_unit`, `remaining_qty`, `total_valuation_delta`, `reason`, `status`) VALUES
(1, 'CADJ-2026-001', 1, 'LUB-VG46-200L', 'Turbine Lubricating Oil Shell Turbo T 46', 90000.00, 92500.00, 2500.00, 28, 70000.00, 'Port terminal customs demurrage and import cess apportionment', 'Approved & Applied')
ON DUPLICATE KEY UPDATE `adjustment_ref`=VALUES(`adjustment_ref`);

-- Quantity Corrections
INSERT INTO `qty_corrections` (`id`, `correction_ref`, `batch_id`, `sku`, `item_name`, `allocated_qty_before`, `corrected_allocated_qty`, `qty_released_to_free_stock`, `work_order_ref`, `reason`, `status`) VALUES
(1, 'QCOR-2026-001', 3, 'HYD-HOSE-2IN', 'High Pressure Hydraulic Hose 2" 350 Bar', 5, 0, 5, 'WO-VIC-2026-09', 'Cancelled auxiliary governor piping modification released reserved stock back to bin', 'Corrected & Unlocked')
ON DUPLICATE KEY UPDATE `correction_ref`=VALUES(`correction_ref`);

-- Stock Transfers
INSERT INTO `stock_transfers` (`id`, `transfer_ref`, `from_location`, `to_department`, `sku`, `item_name`, `quantity`, `transfer_date`, `status`) VALUES
(1, 'TRF-2026-001', 'Victoria Main Stores', 'Mechanical Maintenance Workshop', 'GRS-SHL-18KG', 'Generator Bearing Grease Shell Gadus S2', 3, '2026-02-20', 'Completed'),
(2, 'TRF-2026-002', 'Victoria Main Stores', 'Civil & Dam Instrumentation Bay', 'HYD-HOSE-2IN', 'High Pressure Hydraulic Hose 2" 350 Bar', 2, '2026-02-24', 'Completed')
ON DUPLICATE KEY UPDATE `transfer_ref`=VALUES(`transfer_ref`);

